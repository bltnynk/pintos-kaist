#ifndef _VM_INSPECT_H_
#define _VM_INSPECT_H_
void register_inspect_intr (void);
#endif
